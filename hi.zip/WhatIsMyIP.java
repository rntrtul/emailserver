public class WhatIsMyIP{
    public static void main (String[] main){
	System.out.println(NetIO.myIPAddress());
	//10.206.130.8 farhan
    }
}   
